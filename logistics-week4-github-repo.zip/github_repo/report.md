# Week 4 Task: Predictive Modeling and Optimization in Logistics Systems

**Analytical Report — Shipment-Volume Forecasting and Late-Delivery Risk Modeling for a Regional Distribution Hub**

Prepared by: Intern — Data Analytics (Logistics)
Date: October 2026
Program: Week 4 — Predictive Modeling and Optimization in Logistics Systems

---

## Executive Summary

This report presents the modeling phase of the logistics analytics project defined in Week 1 (strategic planning), grounded in Week 2 (data preprocessing), and explored in Week 3 (EDA and visualization). The scenario is unchanged: optimizing last-mile delivery operations and inventory planning for a regional distribution hub serving urban and semi-urban customers.

Two prediction problems were defined, both tied directly to the Week 1 KPIs:

- **Problem A — 7-day-ahead daily shipment volume forecasting (regression).** Predicts how many shipments the hub must handle seven days out, the planning horizon for driver and vehicle rostering. The champion model, a Random Forest, achieves **RMSE 18.92 shipments, MAE 14.39, R² 0.864** on a chronological holdout test covering the Nov–Dec 2026 peak season — far ahead of the seasonal-naive baseline (RMSE 79.89) and the Ridge baseline (RMSE 30.39).
- **Problem B — per-order late-delivery risk (classification)**, i.e., will this order breach the 48-hour SLA? The selected model, a Logistic Regression chosen on validation F1, achieves **accuracy 0.695, precision 0.427, recall 0.524, F1 0.471, ROC-AUC 0.693** on the peak-season test set. A companion regression on exact delivery hours confirmed that point-prediction of hours is not viable (R² ≈ 0.02) — the operationally correct use of the model is **risk ranking**, not hour prediction.

All models were trained and evaluated for real: a synthetic 9-month dataset (60,996 deliveries, 275 days, fixed seeds) was generated to extend the Week 3 simulation through the Diwali and year-end peak seasons, measuring overall OTD at 72.0% with the same zone disparities Week 3 found. Walk-forward / chronological validation was used throughout — no model ever saw future data — and a small hyperparameter search was run with honest reporting of where tuning helped (HGB volume model: RMSE 42.20 → 33.73) and where it did not (the winning models).

Permutation importance reveals the controllable drivers of lateness: **address risk** (AUC drop 0.098), **vehicles down for maintenance** (0.043), and **route overload** (0.012), alongside vehicle-reliability and zone effects. Three optimization strategies follow directly: (1) forecast-driven vehicle rostering from the Problem A model; (2) morning late-risk triage — priority dispatch and address re-verification for the top-20% risk orders, simulated to cut the late rate from 25.9% to 22.1%; and (3) targeted fixes to the three drivers (address hygiene at intake, maintenance scheduling discipline, load-balanced route cuts). All simulation assumptions are labeled as such.

---

## 1. Problem Definition

### 1.1 Problem A — 7-day-ahead shipment volume forecasting

**Statement.** Predict `shipments[t+7]`, the number of parcels the hub must dispatch seven days from today, using only information available at day `t`.

**Why it matters.** Nearly every operational decision at the hub is a capacity decision made days in advance: how many drivers to roster, how many vehicles to fuel and assign, how much sortation labor to schedule. Week 3 showed that promotional spikes roughly double a normal day's load (the August sale hit 396 shipments against a ~200 mean) and that static staffing fails on exactly those days. A reliable 7-day forecast converts rostering from reaction to planning, and it directly serves two Week 1 KPIs — transportation cost per delivery (fewer emergency vehicle hires) and the 92% OTD target (no overload-driven lateness). The forecast also feeds inventory planning: the hub's outbound volume is the demand signal for safety-stock review.

### 1.2 Problem B — per-order late-delivery risk

**Statement.** At dispatch time, predict `late ∈ {0,1}`: will this order's delivery exceed the 48-hour SLA? A secondary regression variant predicts `delivery_hours` itself.

**Why it matters.** Week 3 measured OTD at 74.5% (this phase's extended dataset: 72.0%) against a 92% target, with 25.5% of deliveries breaching the SLA behind a healthy 32.3-hour median — the tail, not the median, is the problem. A risk score per order lets dispatchers triage the morning's dispatch list: high-risk orders get priority loading, experienced drivers, and proactive customer communication, while low-risk orders flow normally. This serves the OTD KPI and first-attempt success directly, and it is cheaper than adding vehicles.

### 1.3 What "good" looks like

For Problem A, success is a forecast accurate enough to roster on: the internal bar set here is MAE under 20 shipments (~10% of mean daily volume). For Problem B, success is a risk ranking that concentrates lateness in the top scores — measured by ROC-AUC and by precision in the top-risk deciles, since only the top slice will receive intervention.

---

## 2. Dataset and Features

### 2.1 Simulation design

Company systems were not available, so this phase extends the Week 3 simulation approach: a hypothetical dataset generated with fixed seeds (`202604`), now covering **1 April – 31 December 2026 (275 days)** to include the Diwali (Oct–Nov) and Christmas peak seasons that stress-test any model. The design encodes the Week 3 measured patterns — zone-level OTD disparities, the ~24% weekend volume dip, festival spikes, monsoon penalties in semi-urban zones, long-tailed delivery times, distance-driven costs — plus three operational stress effects the models are meant to discover: vehicle-reliability differences, route overload on peak days, and hub-level vehicle downtime.

Measured properties of the generated data (all computed, none assumed):

| Property | Value |
|---|---|
| Deliveries | 60,996 |
| Days | 275 (2026-04-01 to 2026-12-31) |
| Overall OTD (≤48h SLA) | 72.0% |
| OTD by period: Apr–Sep / Oct / Nov–Dec | 70.9% / 73.2% / 74.1% |
| Mean daily shipments | 221.8 |
| Late rate in test period (Nov–Dec) | 25.9% |
| Zone late-rate spread (best → worst) | Z1 25.0% → Z8 45.3% |
| Semi-urban vs urban late rate | 43.9% vs 25.4% |

The 72.0% overall OTD sits close to Week 3's measured 74.5%; the small difference reflects the added peak-season months and the stronger operational-stress effects. Zone disparities are preserved: the semi-urban periphery remains roughly twice as late as the urban core.

### 2.2 Feature sets

**Problem A features** (all known at day `t`; the target-day calendar — weekday and promo schedule — is legitimately known 7 days ahead and is included as foresight, not leakage):

| Feature | Description |
|---|---|
| dow, month, is_weekend, promo_day | Calendar context at day `t` |
| fuel_price_rs_l, temp_c | External conditions |
| lag_7, lag_14, lag_28 | Shipments 7/14/28 days ago |
| roll7_mean, roll28_mean, roll7_std | Rolling history ending at `t` |
| dow_fwd, month_fwd, is_weekend_fwd, promo_mult_fwd | Target-day (t+7) calendar — known in advance |

**Problem B features** (all known at dispatch; anything observed after dispatch — actual km, route deviation, failure reason, delivery hours — is excluded to prevent target leakage):

| Feature | Description |
|---|---|
| zone, zone_type, vehicle_id | Where and with what |
| dow, month, monsoon, promo_day | When |
| package_kg, planned_km | What and how far |
| address_risk, customer_avail | Address/customer risk flags |
| fuel_price_rs_l, temp_c | External conditions |
| route_load | Stops assigned to the vehicle that day ÷ 20-stop planning capacity |
| vehicles_down | Vehicles in maintenance that day (known at morning dispatch) |

### 2.3 Train / validation / test strategy and the no-leakage rationale

Both problems use **chronological splits** — the only honest validation for time-ordered operations data:

- **Train:** 1 Apr – 30 Sep 2026 (38,109 deliveries; 179 usable daily rows for Problem A)
- **Validation:** 1 – 31 Oct 2026 (8,412 deliveries) — used for model selection and tuning decisions
- **Test:** 1 Nov – 31 Dec 2026 (14,475 deliveries; 61 daily rows) — used exactly once, for final reporting

Problem A additionally uses 5-fold walk-forward cross-validation (`TimeSeriesSplit`) inside the training window. The test window is deliberately the hardest: it contains the Diwali and Christmas peaks, so reported metrics are a stress test, not a fair-weather reading. Leakage controls: lag/rolling features use only history (`shift(1)` minimum); the Problem B target and all post-dispatch columns never enter the feature matrix; the ColumnTransformer for the linear model is fit on train only.

A note on why chronological splitting is non-negotiable here: random shuffling would let the model train on December's Diwali patterns and "predict" August — a leakage that flatters metrics while teaching nothing about the future. Logistics data also drifts (the growth trend, the monsoon window), so a model validated on shuffled data would face a different distribution in production than in testing. The chronological design mirrors deployment exactly: the model only ever predicts forward.

---

## 3. Model Selection

### 3.1 Problem A candidates

| Model | Why it was selected |
|---|---|
| **Seasonal naive** (`ŷ[t+7] = shipments[t]`) | The "do nothing smart" baseline. Any model must beat weekly persistence to justify its complexity. |
| **Ridge regression** | Linear baseline with mild regularization. Chosen because volume is strongly driven by a few additive calendar effects (weekday, promo multiplier) — if the world is linear, Ridge finds it cheaply and interpretably. |
| **Random Forest** | Non-linear baseline that captures interactions (e.g., promo × weekend) without manual feature engineering, and is robust to the small sample (240 daily rows). |
| **HistGradientBoosting** | State-of-the-art tabular learner, included to test whether boosting beats bagging on this small, noisy series. |

The candidate set deliberately spans the bias–variance spectrum. With only 240 daily rows for Problem A, high-capacity models risk memorizing noise — which is exactly why the seasonal naive is present: if a 300-tree forest cannot beat "same as last week," the honest conclusion is that the series is unforecastable at this horizon, not that a bigger model is needed. For Problem B, the three classifiers span linear, bagged, and boosted approaches so the validation results reveal the shape of the signal (additive vs interactive) rather than just a leaderboard.

### 3.2 Problem B candidates

| Model | Why it was selected |
|---|---|
| **Logistic Regression** (scaled numerics + one-hot categoricals, `class_weight="balanced"`) | Interpretable linear baseline; calibrated probabilities suit risk ranking. Balanced weights reflect the business asymmetry: missing a late delivery costs more than a false alarm. |
| **Random Forest** (300 trees, balanced weights) | Non-linear baseline for interactions (e.g., monsoon × semi-urban). |
| **HistGradientBoosting** | Strong tabular learner, to test whether boosting extracts more signal. |

A short **delivery-hours regression** (Ridge vs Random Forest on log-hours, back-transformed for reporting) was included as Problem B's regression half, to test whether exact-hour prediction is viable.

On the class-imbalance question: the late class is 25.9% of the test set — imbalanced but not extreme. Balanced class weights were used for the linear and forest models to reflect the business asymmetry (a missed late delivery costs a redelivery trip and an SLA penalty; a false alarm costs a phone call). The decision threshold was kept at 0.5 for reporting, but Section 7.2 shows why operations should think in terms of top-k risk slices rather than a fixed threshold: the triage capacity, not the threshold, is the binding constraint.

---

## 4. Implementation

Representative excerpts (full runnable scripts in the repository):

Walk-forward training and holdout evaluation for Problem A:

```python
tscv = TimeSeriesSplit(n_splits=5)
for name, model in models.items():
    rmses = []
    for tri, tei in tscv.split(Xtr):          # train only on the past, test on the future
        model.fit(Xtr[tri], ytr[tri])
        rmses.append(rmse(ytr[tei], model.predict(Xtr[tei])))
    model.fit(Xtr, ytr)                        # refit on full train
    r, m, s = metrics(yte, model.predict(Xte)) # one look at the test set
```

Leakage-safe preprocessing for the Problem B linear model:

```python
pre = ColumnTransformer([
    ("num", StandardScaler(), NUM),
    ("cat", OneHotEncoder(handle_unknown="ignore"), CAT)])
lr = Pipeline([("pre", pre),
               ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
```

Hyperparameter search (example: the volume HGB):

```python
gs = GridSearchCV(HistGradientBoostingRegressor(random_state=42),
                  {"learning_rate": [0.05, 0.1],
                   "max_leaf_nodes": [31, 63],
                   "min_samples_leaf": [20, 50]},
                  cv=TimeSeriesSplit(n_splits=3),
                  scoring="neg_root_mean_squared_error")
```

Late-risk triage rule (the optimization logic of Section 7):

```python
risk = lr.predict_proba(dispatch_features)[:, 1]   # dispatch-time features only
priority = np.argsort(-risk)[:int(0.20 * len(risk))]  # top-20% risk slice
# priority orders: first-wave loading + address re-verification call
```

---

## 5. Evaluation and Validation

### 5.1 Problem A — volume forecast

![Figure 1: 7-day-ahead forecast vs actual](charts/fig1_forecast_ts.png)
*Figure 1: Random Forest 7-day-ahead forecast against actual daily shipments on the peak-season test set (25 Oct – 24 Dec 2026). The model tracks both the weekly rhythm and the Diwali/Christmas spikes.*

| Model | CV RMSE (5-fold walk-forward) | Test RMSE | Test MAE | Test R² |
|---|---|---|---|---|
| Seasonal naive | — | 79.89 | 53.74 | −1.428 |
| Ridge | 30.84 | 30.39 | 25.09 | 0.649 |
| **Random Forest** | **24.35** | **18.92** | **14.39** | **0.864** |
| HistGradientBoosting | 50.92 | 42.20 | 39.22 | 0.322 |
| HGB tuned (lr 0.05, 31 leaves, min-leaf 50) | — | 33.73 | 30.53 | 0.567 |
| RF tuned (200 trees, depth None, min-leaf 1) | — | 19.25 | 14.53 | 0.859 |

Model selection was by walk-forward CV RMSE, which chose Random Forest before the test set was ever touched. The champion's **MAE of 14.39 shipments is ~6.5% of mean daily volume** — comfortably inside the 10% bar for rostering use.

![Figure 2: Predicted vs actual scatter](charts/fig2_pred_vs_actual.png)
*Figure 2: Predicted vs actual daily shipments (test set). Points cluster tightly on the diagonal; the two high-volume outliers are the Diwali peak days, slightly under-predicted.*

![Figure 3: Residual diagnostics](charts/fig3_residuals.png)
*Figure 3: Residuals vs predicted (left) and residual distribution (right). Residuals are roughly symmetric with no strong funnel shape; the mean residual is +6.72 shipments — a mild systematic under-prediction in the peak test window, worth noting for rostering buffers.*

Three honest observations: (1) tuning helped the weak HGB substantially (RMSE 42.20 → 33.73) but could not make it competitive; (2) tuning the winner changed nothing (19.25 vs 18.92) — diminishing returns are a finding, not a failure; (3) the residual mean of +6.72 means the forecast runs slightly lean in peak season, so rosters should carry a small buffer rather than the raw point forecast.

Reading Figure 1 closely, the model earns its R² of 0.864 in two places. First, it nails the weekly rhythm — the weekend dips are predicted almost exactly, which is why the lag-7 and day-of-week-forward features matter so much. Second, it captures the promo spikes: the Diwali window's ~1.7× surge is tracked, not missed, which is the direct payoff of including the target-day promo calendar as legitimate foresight. The misses are instructive too: the two highest-volume Diwali days are slightly under-predicted (the Figure 2 outliers above the diagonal), consistent with the +6.72 residual bias — when demand breaks records, the model hedges toward history. For rostering, that means the forecast is a floor on peak days, not a ceiling, and the 5% buffer in Section 7.1 is doing real work, not decoration.

### 5.2 Problem B — late-delivery risk (classification)

![Figure 4: ROC curves](charts/fig4_roc.png)
*Figure 4: ROC curves on the peak-season test set. All three models clearly beat chance; Logistic Regression leads with AUC 0.693.*

| Model | Val F1 | Val AUC | Test acc | Test prec | Test rec | Test F1 | Test AUC |
|---|---|---|---|---|---|---|---|
| **Logistic Regression** | **0.459** | **0.681** | **0.695** | **0.427** | **0.524** | **0.471** | **0.693** |
| Random Forest | 0.426 | 0.652 | 0.696 | 0.421 | 0.454 | 0.437 | 0.668 |
| HistGradientBoosting | 0.382 | 0.669 | 0.732 | 0.477 | 0.372 | 0.418 | 0.685 |
| HGB tuned | — | — | 0.734 | 0.481 | 0.349 | 0.405 | 0.686 |

Model selection was by **validation F1** (October), keeping the test set untouched until final reporting — Logistic Regression won there and held its lead on test. Note the instructive upset: the simplest model beat both ensembles. The lateness signal in this data is largely additive and monotonic (risk flags, downtime, overload add up), while the tree ensembles chased noise in the 38k training rows. That is a legitimate modeling lesson, reported as found.

Tuning the HGB (learning rate 0.1, 31 leaves, min-leaf 200) lifted accuracy and precision marginally but **reduced** F1 (0.418 → 0.405) and recall — another honest negative result: tuning for the wrong objective hurts the one that matters.

What do these numbers mean operationally? With precision 0.427 and recall 0.524, the Logistic Regression flags roughly two orders as risky for every one that is truly late, while catching just over half of all late deliveries. That sounds unimpressive until the alternative is stated: without the model, dispatchers triage by gut feel, which Week 3 showed is effectively random across the 25.9% base rate. The model's value is concentration, not perfection — the top-20% risk slice is 48.2% late, nearly double the base rate, which is what makes the Section 7.2 intervention economics work. A model with these metrics should never auto-cancel or auto-penalize; it should route cheap preventive effort (a call, priority loading) toward the densest risk.

### 5.3 Problem B — delivery-hours regression

| Model | Test RMSE | Test MAE | Test R² |
|---|---|---|---|
| Ridge (log-hours) | 41.53 h | 16.80 h | 0.018 |
| Random Forest (log-hours) | 41.38 h | 18.53 h | 0.025 |

The regression half of Problem B effectively fails: R² ≈ 0.02 means the models explain almost none of the hour-to-hour variance. Exact delivery times retain large irreducible randomness (traffic, customer-side delays). The operational conclusion is sharp and important: **do not promise hours — rank risk.** The classification model (AUC 0.69) is useful precisely because ranking is an easier, better-posed task than point prediction here.

![Figure 6: Model comparison](charts/fig6_model_comparison.png)
*Figure 6: Left — Problem A test RMSE by model (lower is better). Right — Problem B test F1 and ROC-AUC by model.*

---

## 6. Model Interpretation — What Drives Lateness?

Permutation importance on the tuned HGB (mean ROC-AUC drop when a feature is shuffled, test set):

![Figure 5: Feature importance](charts/fig5_feat_importance.png)
*Figure 5: Top drivers of lateness. Address risk dominates; hub vehicle downtime and route overload follow; individual vehicle-reliability effects and zone structure contribute.*

| Rank | Feature | AUC drop | Operational reading |
|---|---|---|---|
| 1 | address_risk | 0.0983 | Bad/incomplete addresses are the #1 lateness driver — matches Week 3's Pareto (wrong addresses = 26.1% of failures) |
| 2 | vehicles_down | 0.0430 | Each vehicle in maintenance measurably raises everyone's lateness — hub-level capacity, not bad luck |
| 3 | route_load | 0.0115 | Overloaded vehicle-days (>20 planned stops) run late — the rostering link |
| 4–5 | vehicle_id_V09, V07 | 0.0071 / 0.0034 | Specific vehicles are systematically slower — maintenance/driver assignment signal |
| 6 | zone_type_urban | 0.0024 | Geography still matters after controls — the semi-urban structural gap persists |

The model independently rediscovered Week 3's diagnosis and sharpened it: the address pipeline is the biggest lever, hub capacity discipline (maintenance scheduling) is second, and overload is third. Notably, `planned_km` matters only modestly (0.0058) — consistent with Week 3's finding that route *deviation*, not distance, was never the lateness story.

Two drivers deserve a closer look. **Vehicles down (0.043)** is a hub-level variable: it does not describe the order at all, yet it is the second-strongest predictor. That means lateness is contagious — when two or three vehicles sit in maintenance, every route that day absorbs the spillover through reallocated stops and compressed time windows. The fix is therefore a capacity policy (Section 7.3), not better driving. **Route load (0.012)** validates the Week 1 rostering hypothesis with a number: each unit of overload above the 20-stop planning capacity multiplies lateness risk, which is why the Problem A forecast and the Problem B model are not two projects but one system — the forecast prevents the overload the risk model would otherwise have to triage. The vehicle-specific effects (V09, V07) are the smallest actionable finding with the fastest payoff: two vehicles are measurably slower across all zones and months, which points at maintenance or driver assignment, checkable this week.

---

## 7. Optimization Strategies

Each strategy is tied to a model insight, with quantified expected impact. Simulation-based figures are labeled as labeled assumptions, not measurements.

### 7.1 Forecast-driven rostering (from Problem A)

**Insight.** The RF forecast predicts next week's daily volume within ±14.4 shipments (MAE), and the route_load feature proves overload drives lateness.

**Action.** Each evening, roster `ceil(forecast[t+7] / 20)` vehicle-shifts for the day a week out (20 = planning capacity per shift), rather than the current flat roster.

**Quantified.** On the 61 test days, forecast-based rostering matched the actually-needed shifts on 30 days; it under-rostered on 23 days and over-rostered on 8. The 23 under-rostered days are exactly the overload days the model flags as lateness-prone. Combined with the +6.72 residual bias finding, the rule becomes: roster the forecast **plus a 5% buffer** on predicted peak days. Expected effect (target): eliminate overload-driven lateness, which the model attributes to roughly a tenth of late deliveries.

### 7.2 Morning late-risk triage (from Problem B)

**Insight.** The risk ranking concentrates lateness: the top-10% risk orders are 56.5% late, the top-20% are 48.2% late, against a 25.9% base rate.

**Action.** Score each morning's dispatch list at load time; the top-20% risk slice gets first-wave loading, address re-verification calls, and proactive customer ETA communication.

**Quantified (simulation, labeled assumption: intervention prevents 40% of lateness among the truly-late intervened orders).** Of 2,895 intervened test orders, 1,395 were truly late; preventing 40% (558) moves the test-set late rate from **25.9% → 22.1%** — a 3.8-point OTD gain from process, not fleet.

![Figure 7: Optimization illustration](charts/fig7_optimization.png)
*Figure 7: Left — simulated late-rate impact of triaging the top-20% risk orders (40% prevention effectiveness assumed and labeled). Right — forecast-driven vehicle rostering vs actual shift need across the test period.*

### 7.3 Fix the three modeled drivers

| Driver (importance) | Fix | Expected effect (target) |
|---|---|---|
| Address risk (0.098) | Address validation + access-code capture at order intake (Week 3 rec. #2); re-verification call for flagged orders | Cut the #1 lateness driver at its source |
| Vehicles down (0.043) | Cap concurrent maintenance at 1 vehicle; pre-position a spare vehicle on high-downtime days | Remove hub-level lateness shocks |
| Route overload (0.012) | Split any vehicle-day forecast above 20 stops (Section 7.1); rebalance semi-urban zones (Week 3 rec. #3) | Attack the costliest zones' lateness directly |

### 7.4 Inventory implication

The volume forecast doubles as the demand signal for safety-stock review: pre-build stock before the Diwali/Christmas windows the model now quantifies, addressing Week 3's finding that the slowest-turning categories stock out most.

### 7.5 Pilot design — measure before scaling

None of the quantified impacts above should be taken on faith. The recommended pilot: run triage (7.2) and forecast rostering (7.1) on two zones — one urban (Z2) and one semi-urban (Z6) — for two weeks, holding the other six zones as controls. Track daily OTD, late rate in the triaged slice vs the untriaged remainder, rostered vs needed shifts, and intervention cost (dispatcher minutes per prevented late delivery). Go/no-go criteria, set in advance: triage is scaled if the treated zones gain ≥2 OTD points vs controls at a cost below the redelivery cost it displaces; rostering is scaled if under-rostered days fall by half. This is the Week 1 roadmap's Phase 5 (validation and rollout), now with concrete success metrics.

---

## 8. Limitations and Risks

- **Simulated data.** All patterns are realistic but synthetic; every finding must be re-validated on hub systems before operational changes. The test set is the peak season — metrics are a stress test, and fair-weather months will look better.
- **Modest classification power (AUC 0.69).** Lateness retains substantial irreducible randomness; the model is a triage aid, not an oracle. Precision of 0.43 means most flagged orders still arrive on time — interventions must be cheap (a phone call, priority loading), never punitive.
- **Regression on hours is not viable (R² ≈ 0.02).** Do not use hour predictions for customer promises; use the risk ranking.
- **The 40% triage effectiveness is an assumption**, labeled as such — pilot it on 2–3 zones for two weeks and measure before scaling.
- **Promo-calendar foresight** assumes the marketing calendar is locked 7+ days ahead; last-minute flash sales will degrade Problem A accuracy (the residual diagnostics show where).
- **Class imbalance and threshold choice.** The 0.5 decision threshold was kept for reporting; operations should tune the triage cutoff (top-10/20/30%) against intervention capacity, using the precision@k figures in Section 7.2.
- **Model monitoring and drift.** The promo calendar, fleet composition, and zone map all change; a model trained on Apr–Dec 2026 will decay. Retrain monthly, track live precision@20% against the 0.482 benchmark, and alert if the forecast's residual mean drifts beyond ±10 shipments — the signature of a structural change (new zone, new client, fleet change).
- **Fairness across zones.** The risk model must not become an excuse to deprioritize semi-urban zones: triage directs *extra* effort to high-risk orders, never less effort to high-risk zones. Monitor OTD by zone during the pilot to confirm the gap narrows rather than being managed by neglect.

---

## 9. Conclusion

The modeling phase converted three weeks of analysis into two working predictive tools. A Random Forest forecasts 7-day shipment volume within ±14.4 shipments (R² 0.864), making driver and vehicle rostering a planning exercise instead of a reaction. A Logistic Regression ranks per-order late risk at AUC 0.693 — modest in absolute terms, but operationally decisive: the top-risk fifth of orders contains nearly half of all late deliveries, and triaging it simulates a 3.8-point OTD gain. The honest negative results matter as much: the simplest classifier beat the ensembles, tuning had diminishing returns, and exact hour prediction is a dead end (R² ≈ 0.02) — rank, don't predict.

The models agree with, and sharpen, everything Weeks 1–3 found: address hygiene first, hub capacity discipline second, overload third, with the semi-urban periphery needing structural attention. The path to the 92% OTD target is now quantified: ~4 points from triage process, more from rostering discipline and the driver fixes — each measurable in a pilot before any fleet money is spent.

---

## 10. References and Data Sources

As in Weeks 1–3, sources are described generically; no citations are fabricated:

- Public logistics and e-commerce shipment datasets on open data platforms (structural reference for the simulation schema).
- scikit-learn documentation: `TimeSeriesSplit`, `GridSearchCV`, `HistGradientBoostingClassifier`, `permutation_importance`, and regression/classification metric definitions (RMSE, MAE, R², precision, recall, F1, ROC-AUC).
- Standard time-series validation methodology: walk-forward (rolling-origin) evaluation for forecasting; chronological holdout for operational data.
- The Week 1 strategic planning report, Week 2 preprocessing report, and Week 3 EDA/visualization report of this same project (scenario, KPI definitions, preprocessing lineage, and measured baselines reused here).

---

## Appendix A — Code Excerpts

Problem A feature engineering (no-leakage lags; target-day calendar as legitimate foresight):

```python
for lag in (7, 14, 28):
    df[f"lag_{lag}"] = df["shipments"].shift(lag)
df["roll7_mean"] = df["shipments"].shift(1).rolling(7).mean()
df["target"] = df["shipments"].shift(-7)          # 7-day-ahead target
df["promo_mult_fwd"] = df["promo_mult"].shift(-7) # promo calendar: known in advance
```

Problem B dispatch-time feature discipline (post-dispatch columns excluded):

```python
NUM = ["dow", "month", "monsoon", "promo_day", "package_kg", "planned_km",
       "address_risk", "customer_avail", "fuel_price_rs_l", "temp_c",
       "route_load", "vehicles_down"]   # actual_km / route_deviation / failure_reason excluded
CAT = ["zone", "zone_type", "vehicle_id"]
```

Full runnable scripts — `generate_dataset.py`, `train_volume_forecast.py`, `train_late_risk_model.py`, `make_charts.py`, `build_docx.py` — are in the accompanying repository; every number in this report was produced by running them.
