"""Problem B: per-order late-risk prediction (will this delivery breach the 48h SLA?).

Target: late (1 = delivery_hours > 48). Features are DISPATCH-TIME only -
anything observed after dispatch (actual_km, route deviation, failure reason,
delivery_hours itself) is excluded to prevent target leakage.

Models compared:
  1. Logistic Regression (linear baseline; scaled numerics + one-hot categoricals)
  2. Random Forest (non-linear; class_weight='balanced' - missing a late
     delivery costs more than a false alarm, so recall is prioritized)
  3. HistGradientBoosting (strong tabular learner, native categorical support)

Validation: chronological split - train Apr-Sep 2026, validation Oct 2026,
test Nov-Dec 2026 (peak season: Diwali + Christmas - the hardest, most
honest test). Metrics: accuracy, precision, recall, F1, ROC-AUC.
GridSearchCV tunes the best model; tuned vs untuned reported.
A short delivery-hours REGRESSION (Ridge vs RandomForest on log-hours) is
included as the regression half of Problem B.
"""
import json
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, mean_squared_error,
                             mean_absolute_error, r2_score)

BASE = Path(__file__).resolve().parent.parent
d = pd.read_csv(BASE / "data" / "deliveries.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)

NUM = ["dow", "month", "monsoon", "promo_day", "package_kg", "planned_km",
       "address_risk", "customer_avail", "fuel_price_rs_l", "temp_c",
       "route_load", "vehicles_down"]
CAT = ["zone", "zone_type", "vehicle_id"]
y = d["late"].values

# chronological split
tr = d["date"] <= "2026-09-30"
va = (d["date"] >= "2026-10-01") & (d["date"] <= "2026-10-31")
te = d["date"] >= "2026-11-01"
print(f"train={tr.sum()}  val={va.sum()}  test={te.sum()}  "
      f"late-rate train={y[tr].mean():.3f} val={y[va].mean():.3f} test={y[te].mean():.3f}")

X = d[NUM + CAT]
Xtr, Xva, Xte = X[tr], X[va], X[te]
ytr, yva, yte = y[tr], y[va], y[te]

def clf_metrics(yt, yp, pp):
    return dict(accuracy=round(float(accuracy_score(yt, yp)), 4),
                precision=round(float(precision_score(yt, yp, zero_division=0)), 4),
                recall=round(float(recall_score(yt, yp, zero_division=0)), 4),
                f1=round(float(f1_score(yt, yp, zero_division=0)), 4),
                roc_auc=round(float(roc_auc_score(yt, pp)), 4))

# --- 1. Logistic Regression (needs scaled numerics + one-hot) ---
pre = ColumnTransformer([
    ("num", StandardScaler(), NUM),
    ("cat", OneHotEncoder(handle_unknown="ignore"), CAT)])
lr = Pipeline([("pre", pre),
               ("clf", LogisticRegression(max_iter=1000, class_weight="balanced"))])
lr.fit(Xtr, ytr)

# --- 2/3. tree models on one-hot frame ---
Xoh = pd.get_dummies(X, columns=CAT)
Xotr, Xova, Xote = Xoh[tr], Xoh[va], Xoh[te]
rf = RandomForestClassifier(n_estimators=300, class_weight="balanced",
                            n_jobs=-1, random_state=42)
rf.fit(Xotr, ytr)
hgb = HistGradientBoostingClassifier(random_state=42)
hgb.fit(Xotr, ytr)

results = {}
probs = {}
val_f1 = {}
for name, est, Xv, Xt in [("LogisticRegression", lr, Xva, Xte),
                          ("RandomForest", rf, Xova, Xote),
                          ("HistGradientBoosting", hgb, Xova, Xote)]:
    ppv = est.predict_proba(Xv)[:, 1]
    mv = clf_metrics(yva, (ppv >= 0.5).astype(int), ppv)
    pp = est.predict_proba(Xt)[:, 1]
    yp = (pp >= 0.5).astype(int)
    results[name] = {"val": mv, "test": clf_metrics(yte, yp, pp)}
    probs[name] = pp
    val_f1[name] = mv["f1"]
    m = results[name]["test"]
    print(f"[{name:22s}] VAL  f1={mv['f1']:.3f} auc={mv['roc_auc']:.3f} | "
          f"TEST acc={m['accuracy']:.3f} prec={m['precision']:.3f} "
          f"rec={m['recall']:.3f} f1={m['f1']:.3f} auc={m['roc_auc']:.3f}")

# --- model selection on the VALIDATION set (test stays untouched until final) ---
best_name = max(val_f1, key=val_f1.get)
print(f"\nselected on validation F1: {best_name} (test set still untouched)")

grid = {"learning_rate": [0.05, 0.1], "max_leaf_nodes": [31, 63],
        "min_samples_leaf": [50, 200]}
gs = GridSearchCV(HistGradientBoostingClassifier(random_state=42), grid,
                  cv=StratifiedKFold(n_splits=3, shuffle=True, random_state=42),
                  scoring="f1", n_jobs=-1)
gs.fit(Xotr, ytr)
pp = gs.best_estimator_.predict_proba(Xote)[:, 1]
tuned_m = clf_metrics(yte, (pp >= 0.5).astype(int), pp)
print(f"[HGB tuned {gs.best_params_}] TEST acc={tuned_m['accuracy']:.3f} "
      f"prec={tuned_m['precision']:.3f} rec={tuned_m['recall']:.3f} "
      f"f1={tuned_m['f1']:.3f} auc={tuned_m['roc_auc']:.3f}")
results["HistGradientBoosting-tuned"] = {"test": tuned_m, "params": gs.best_params_}
probs["HistGradientBoosting-tuned"] = pp

# --- feature importance via permutation (HGB exposes no impurity importance) ---
from sklearn.inspection import permutation_importance
rng_sub = np.random.default_rng(7)
sub = rng_sub.choice(len(Xote), size=min(3000, len(Xote)), replace=False)
perm = permutation_importance(gs.best_estimator_, Xote.iloc[sub], yte[sub],
                              n_repeats=5, random_state=42, n_jobs=-1,
                              scoring="roc_auc")
imp = pd.Series(perm.importances_mean, index=Xote.columns).sort_values(ascending=False)
print("\ntop-12 features by permutation importance / ROC-AUC drop (tuned HGB):")
print(imp.head(12).round(4).to_string())
imp.round(4).to_csv(BASE / "data" / "late_feature_importance.csv")

# --- Problem B regression half: predict delivery_hours (log scale) ---
ylog = np.log1p(d["delivery_hours"].values)
rreg = Ridge(alpha=1.0)
rreg.fit(Xotr, ylog[tr])
rfreg = RandomForestRegressor(n_estimators=200, n_jobs=-1, random_state=42)
rfreg.fit(Xotr, ylog[tr])
print("\ndelivery-hours regression (test, back-transformed):")
reg_rows = []
for name, est in [("Ridge", rreg), ("RandomForest", rfreg)]:
    pred_h = np.expm1(est.predict(Xote))
    true_h = d.loc[te, "delivery_hours"].values
    rmse = float(np.sqrt(mean_squared_error(true_h, pred_h)))
    mae = float(mean_absolute_error(true_h, pred_h))
    r2 = float(r2_score(true_h, pred_h))
    reg_rows.append((name, rmse, mae, r2))
    print(f"[{name:14s}] RMSE={rmse:6.2f}h MAE={mae:5.2f}h R2={r2:+.3f}")

# --- save test-set probabilities for ROC + optimization simulation ---
pd.DataFrame({"late": yte,
              **{f"p_{k}": v for k, v in probs.items()}}).to_csv(
    BASE / "data" / "late_test_pred.csv", index=False)
json.dump({"classification": results,
           "regression": [{"model": n, "rmse_h": r, "mae_h": m, "r2": s}
                          for n, r, m, s in reg_rows]},
          open(BASE / "data" / "late_metrics.json", "w"), indent=1)
print("\nsaved data/late_test_pred.csv, data/late_metrics.json, data/late_feature_importance.csv")
