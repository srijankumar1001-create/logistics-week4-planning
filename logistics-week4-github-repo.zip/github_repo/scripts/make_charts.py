"""Generate all Week 4 charts from real model outputs. Prints key numbers used in prose."""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
from sklearn.metrics import roc_curve, auc

BASE = Path(__file__).resolve().parent.parent
CH = BASE / "charts"
CH.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"figure.dpi": 150, "font.size": 9})

# ------------------------------------------------- Problem A: volume forecast
vp = pd.read_csv(BASE / "data" / "volume_test_pred.csv", parse_dates=["date"])
vm = json.load(open(BASE / "data" / "volume_metrics.json"))

# Fig 1: forecast vs actual time series (test period)
fig, ax = plt.subplots(figsize=(10, 4.2))
ax.plot(vp["date"], vp["actual"], alpha=0.55, label="Actual shipments")
ax.plot(vp["date"], vp["pred"], lw=1.8, label="RF forecast (7-day ahead)")
ax.set_title("Problem A — 7-day-ahead volume forecast vs actual (test: 25 Oct – 24 Dec 2026)")
ax.set_ylabel("Daily shipments")
ax.legend(); fig.autofmt_xdate(); fig.tight_layout()
fig.savefig(CH / "fig1_forecast_ts.png", bbox_inches="tight"); plt.close(fig)

# Fig 2: predicted vs actual scatter
fig, ax = plt.subplots(figsize=(4.6, 4.2))
ax.scatter(vp["actual"], vp["pred"], s=12, alpha=0.6)
lo, hi = vp["actual"].min(), vp["actual"].max()
ax.plot([lo, hi], [lo, hi], "r--", lw=1.2, label="Perfect forecast")
ax.set_xlabel("Actual shipments"); ax.set_ylabel("Predicted shipments")
ax.set_title("Predicted vs actual (RF, test set)")
ax.legend(); fig.tight_layout()
fig.savefig(CH / "fig2_pred_vs_actual.png", bbox_inches="tight"); plt.close(fig)

# Fig 3: residuals
resid = vp["actual"] - vp["pred"]
fig, axes = plt.subplots(1, 2, figsize=(9, 3.8))
axes[0].scatter(vp["pred"], resid, s=12, alpha=0.6)
axes[0].axhline(0, color="r", ls="--", lw=1)
axes[0].set_xlabel("Predicted shipments"); axes[0].set_ylabel("Residual (actual - pred)")
axes[0].set_title("Residuals vs predicted")
axes[1].hist(resid, bins=20, edgecolor="white")
axes[1].set_xlabel("Residual"); axes[1].set_title("Residual distribution")
fig.suptitle("Problem A — residual diagnostics (RF)")
fig.tight_layout(); fig.savefig(CH / "fig3_residuals.png", bbox_inches="tight"); plt.close(fig)
print(f"[A] residual mean={resid.mean():.2f} std={resid.std():.2f} | "
      f"max abs err day: {vp.loc[resid.abs().idxmax(), 'date'].date()} ({resid.abs().max():.0f})")

# ------------------------------------------------- Problem B: late-risk ROC
lt = pd.read_csv(BASE / "data" / "late_test_pred.csv")
fig, ax = plt.subplots(figsize=(4.8, 4.4))
for col, label in [("p_LogisticRegression", "Logistic Regression"),
                   ("p_RandomForest", "Random Forest"),
                   ("p_HistGradientBoosting", "HistGradientBoosting"),
                   ("p_HistGradientBoosting-tuned", "HGB tuned")]:
    fpr, tpr, _ = roc_curve(lt["late"], lt[col])
    ax.plot(fpr, tpr, lw=1.6, label=f"{label} (AUC={auc(fpr, tpr):.3f})")
ax.plot([0, 1], [0, 1], "k--", lw=1, label="Chance")
ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
ax.set_title("Problem B — ROC curves (test set, Nov–Dec 2026)")
ax.legend(fontsize=8); fig.tight_layout()
fig.savefig(CH / "fig4_roc.png", bbox_inches="tight"); plt.close(fig)

# Fig 5: permutation feature importance
imp = pd.read_csv(BASE / "data" / "late_feature_importance.csv", index_col=0)
top = imp.head(12)
fig, ax = plt.subplots(figsize=(7.2, 4.4))
ax.barh(top.index[::-1], top["0"][::-1] if "0" in top.columns else top.iloc[::-1, 0])
ax.set_xlabel("Mean ROC-AUC drop under permutation")
ax.set_title("Problem B — top drivers of lateness (permutation importance, tuned HGB)")
fig.tight_layout(); fig.savefig(CH / "fig5_feat_importance.png", bbox_inches="tight"); plt.close(fig)

# Fig 6: model comparison panels
fig, axes = plt.subplots(1, 2, figsize=(10, 4.0))
a_models = ["SeasonalNaive", "Ridge", "RandomForest", "HistGradientBoosting", "HGB tuned", "RF tuned"]
a_rmse = [79.89, 30.39, 18.92, 42.20, 33.73, 19.25]
axes[0].bar(a_models, a_rmse, color=["gray", "steelblue", "darkgreen", "steelblue", "lightblue", "lightgreen"])
axes[0].set_ylabel("Test RMSE (shipments)"); axes[0].set_title("Problem A — forecast error by model")
axes[0].tick_params(axis="x", rotation=18, labelsize=8)
b_models = ["LogReg", "RandForest", "HGB", "HGB tuned"]
b_f1 = [0.471, 0.437, 0.418, 0.405]
b_auc = [0.693, 0.668, 0.685, 0.686]
x = np.arange(len(b_models)); w = 0.36
axes[1].bar(x - w/2, b_f1, w, label="F1")
axes[1].bar(x + w/2, b_auc, w, label="ROC-AUC")
axes[1].set_xticks(x); axes[1].set_xticklabels(b_models)
axes[1].set_title("Problem B — classification quality by model (test)")
axes[1].legend()
fig.tight_layout(); fig.savefig(CH / "fig6_model_comparison.png", bbox_inches="tight"); plt.close(fig)

# Fig 7: optimization illustration -------------------------------------
# (a) triage simulation: intervene on the top-risk 20% of test orders
p = lt["p_LogisticRegression"].values
y = lt["late"].values
order = np.argsort(-p)
print("\n[triage] precision@k on test set:")
for k in (0.10, 0.20, 0.30):
    kk = int(len(y) * k)
    prec = y[order[:kk]].mean()
    print(f"  top {k:.0%}: precision={prec:.3f}  (baseline late rate={y.mean():.3f})")
k = int(len(y) * 0.20)
top_idx = order[:k]
# intervention: priority dispatch + address re-verification; assumed to
# prevent 40% of lateness among the truly-late intervened orders (labeled).
prevented = int(0.40 * y[top_idx].sum())
new_late = y.sum() - prevented
print(f"[triage] intervened={k}, truly-late among them={int(y[top_idx].sum())}, "
      f"prevented(labeled 40%)={prevented}")
print(f"[triage] late rate {y.mean():.3f} -> {new_late/len(y):.3f}")

fig, axes = plt.subplots(1, 2, figsize=(10, 4.0))
labels = ["Baseline", "With triage\n(top-20% risk,\n40% effective)"]
axes[0].bar(labels, [y.mean()*100, new_late/len(y)*100], color=["tomato", "seagreen"])
axes[0].set_ylabel("Late-delivery rate % (test set)")
axes[0].set_title("Simulated impact of late-risk triage")
for i, v in enumerate([y.mean()*100, new_late/len(y)*100]):
    axes[0].text(i, v + 0.3, f"{v:.1f}%", ha="center", fontsize=10)

# (b) rostering from the volume forecast: shifts needed = ceil(volume/20)
need_actual = np.ceil(vp["actual"] / 20).astype(int)
need_pred = np.ceil(vp["pred"] / 20).astype(int)
overload_days = int((need_actual > need_pred).sum())
exact = int((need_actual == need_pred).sum())
print(f"[roster] test days={len(vp)} exact-shift match={exact} "
      f"under-rostered days={overload_days} over-rostered={(need_actual < need_pred).sum()}")
axes[1].plot(vp["date"], need_actual, label="Shifts needed (actual volume)", alpha=0.7)
axes[1].plot(vp["date"], need_pred, label="Shifts rostered (forecast)", lw=1.6)
axes[1].set_ylabel("Vehicle-shifts per day"); axes[1].legend(fontsize=8)
axes[1].set_title("Forecast-driven rostering vs actual need")
fig.autofmt_xdate(); fig.tight_layout()
fig.savefig(CH / "fig7_optimization.png", bbox_inches="tight"); plt.close(fig)

print("\ncharts saved to", CH)
