"""Problem A: 7-day-ahead daily shipment volume forecasting.

Target: shipments[t+7] predicted from information available at day t (lags and
rolling statistics only - no future leakage).

Models compared:
  1. Seasonal naive baseline:  yhat[t+7] = shipments[t]     (weekly persistence)
  2. Ridge regression (linear baseline, alpha=1.0)
  3. Random Forest regressor (non-linear, interactions)
  4. HistGradientBoosting regressor (non-linear, strong tabular learner)

Validation: TimeSeriesSplit walk-forward CV (5 folds) + a final chronological
holdout test (Nov-Dec 2026, last 61 days). Metrics: RMSE, MAE, R^2.
A small GridSearchCV tunes the best model; tuned vs untuned is reported.
"""
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

BASE = Path(__file__).resolve().parent.parent
daily = pd.read_csv(BASE / "data" / "daily.csv", parse_dates=["date"]).sort_values("date").reset_index(drop=True)

# ------------------------------------------------------------------ features
df = daily.copy()
df["dow"] = df["date"].dt.dayofweek
df["month"] = df["date"].dt.month
df["is_weekend"] = (df["dow"] >= 5).astype(int)
df["promo_day"] = (df["promo_mult"] > 1.0).astype(int)
for lag in (7, 14, 28):
    df[f"lag_{lag}"] = df["shipments"].shift(lag)
df["roll7_mean"] = df["shipments"].shift(1).rolling(7).mean()
df["roll28_mean"] = df["shipments"].shift(1).rolling(28).mean()
df["roll7_std"] = df["shipments"].shift(1).rolling(7).std()
# target: volume 7 days ahead, known only from history at prediction time
df["target"] = df["shipments"].shift(-7)
# target-day calendar is known 7 days in advance (promo calendar, weekday):
# this is legitimate foresight, not leakage - the Week 3 report explicitly
# recommended feeding the promotional calendar into the forecast.
df["dow_fwd"] = df["dow"].shift(-7)
df["month_fwd"] = df["month"].shift(-7)
df["is_weekend_fwd"] = df["is_weekend"].shift(-7)
df["promo_mult_fwd"] = df["promo_mult"].shift(-7)
df = df.dropna().reset_index(drop=True)

FEATURES = ["dow", "month", "is_weekend", "promo_day", "fuel_price_rs_l", "temp_c",
            "lag_7", "lag_14", "lag_28", "roll7_mean", "roll28_mean", "roll7_std",
            "dow_fwd", "month_fwd", "is_weekend_fwd", "promo_mult_fwd"]
X = df[FEATURES].values
y = df["target"].values
dates = df["date"]

# chronological holdout: last 61 days (Nov-Dec 2026) = test
cut = len(df) - 61
Xtr, Xte, ytr, yte = X[:cut], X[cut:], y[:cut], y[cut:]
print(f"rows={len(df)}  train={len(Xtr)} (up to {dates.iloc[cut-1].date()})  "
      f"test={len(Xte)} (from {dates.iloc[cut].date()})")

def metrics(yt, yp):
    return (float(np.sqrt(mean_squared_error(yt, yp))),
            float(mean_absolute_error(yt, yp)),
            float(r2_score(yt, yp)))

# ------------------------------------------------- 1. seasonal naive baseline
# yhat for day t+7 from the same weekday one week earlier = shipments[t]
naive_pred = df["lag_7"].values[cut:]  # shipments[t] is lag_7 of target day t+7
rmse, mae, r2 = metrics(yte, naive_pred)
print(f"\n[SeasonalNaive]          RMSE={rmse:7.2f}  MAE={mae:6.2f}  R2={r2:+.3f}")

# ------------------------------------------------- walk-forward CV + models
tscv = TimeSeriesSplit(n_splits=5)
models = {
    "Ridge": Ridge(alpha=1.0),
    "RandomForest": RandomForestRegressor(n_estimators=300, n_jobs=-1, random_state=42),
    "HistGradientBoosting": HistGradientBoostingRegressor(random_state=42),
}
cv_rows, fitted = [], {}
test_rows = []
for name, model in models.items():
    rmses, maes, r2s = [], [], []
    for tri, tei in tscv.split(Xtr):
        model.fit(Xtr[tri], ytr[tri])
        r, m, s = metrics(ytr[tei], model.predict(Xtr[tei]))
        rmses.append(r); maes.append(m); r2s.append(s)
    model.fit(Xtr, ytr)  # refit on full train for the holdout test
    r, m, s = metrics(yte, model.predict(Xte))
    fitted[name] = model
    cv_rows.append((name, np.mean(rmses), np.mean(maes), np.mean(r2s)))
    test_rows.append((name, r, m, s))
    print(f"[{name:20s}] CV: RMSE={np.mean(rmses):7.2f} MAE={np.mean(maes):6.2f} R2={np.mean(r2s):+.3f} | "
          f"TEST: RMSE={r:7.2f} MAE={m:6.2f} R2={s:+.3f}")

# ------------------------------------------------- tune the best model (HGB)
param_grid = {"learning_rate": [0.05, 0.1], "max_leaf_nodes": [31, 63],
              "min_samples_leaf": [20, 50]}
gs = GridSearchCV(HistGradientBoostingRegressor(random_state=42), param_grid,
                  cv=TimeSeriesSplit(n_splits=3),
                  scoring="neg_root_mean_squared_error", n_jobs=-1)
gs.fit(Xtr, ytr)
best = gs.best_estimator_
r, m, s = metrics(yte, best.predict(Xte))
print(f"\n[HGB tuned {gs.best_params_}] TEST: RMSE={r:7.2f} MAE={m:6.2f} R2={s:+.3f}")
print(f"    (untuned HGB test RMSE was {dict((n, v[0]) for n, *v in test_rows)['HistGradientBoosting']:.2f})")

# save test predictions of the best model (RandomForest) for charts
rf_best = fitted["RandomForest"]
pd.DataFrame({"date": dates.iloc[cut:], "actual": yte,
              "pred": rf_best.predict(Xte)}).to_csv(BASE / "data" / "volume_test_pred.csv", index=False)

# ------------------------------------------------- tune the winning model too
rf_grid = {"n_estimators": [200, 400], "max_depth": [None, 12],
           "min_samples_leaf": [1, 5]}
gs_rf = GridSearchCV(RandomForestRegressor(n_jobs=-1, random_state=42), rf_grid,
                     cv=TimeSeriesSplit(n_splits=3),
                     scoring="neg_root_mean_squared_error", n_jobs=-1)
gs_rf.fit(Xtr, ytr)
rf_tuned = gs_rf.best_estimator_
rt, mt, st = metrics(yte, rf_tuned.predict(Xte))
print(f"[RF tuned {gs_rf.best_params_}] TEST: RMSE={rt:7.2f} MAE={mt:6.2f} R2={st:+.3f}")
print(f"    (untuned RF test RMSE was {dict((n, v[0]) for n, *v in test_rows)['RandomForest']:.2f})")

import json
json.dump({"cv": cv_rows, "test": test_rows,
           "hgb_tuned": ("HistGradientBoosting-tuned", r, m, s, gs.best_params_),
           "rf_tuned": ("RandomForest-tuned", rt, mt, st, gs_rf.best_params_)},
          open(BASE / "data" / "volume_metrics.json", "w"), indent=1)
print("\nsaved data/volume_test_pred.csv and data/volume_metrics.json")
