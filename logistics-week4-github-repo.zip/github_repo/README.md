# Week 4 — Predictive Modeling and Optimization in Logistics Systems

Two working predictive models for a regional distribution hub's last-mile operation, continuing the Week 1–3 project (strategic planning → preprocessing → EDA).

## The two problems

| # | Problem | Type | Champion model | Test performance |
|---|---|---|---|---|
| A | 7-day-ahead daily shipment volume | Regression | Random Forest | RMSE 18.92 · MAE 14.39 · R² 0.864 |
| B | Per-order late-delivery risk (48h SLA breach) | Classification | Logistic Regression | Acc 0.695 · F1 0.471 · ROC-AUC 0.693 |

A companion delivery-hours regression (Ridge/RF, R² ≈ 0.02) showed exact-hour prediction is not viable — **rank risk, don't predict hours.**

## Scripts

| Script | What it does |
|---|---|
| `scripts/generate_dataset.py` | Generates the synthetic 9-month dataset (60,996 deliveries, 275 days, fixed seed `202604`) encoding the Week 3 measured patterns plus operational stress effects |
| `scripts/train_volume_forecast.py` | Problem A: feature engineering, 4 candidate models, 5-fold walk-forward CV, chronological holdout test, GridSearchCV tuning |
| `scripts/train_late_risk_model.py` | Problem B: dispatch-time features (no leakage), 3 classifiers, validation-based selection, tuning, permutation importance, hours regression |
| `scripts/make_charts.py` | Generates all 7 charts from real model outputs |
| `scripts/build_docx.py` | Renders `report.md` → the Word report with embedded charts |

## Reproduce

```bash
pip install -r requirements.txt
python scripts/generate_dataset.py
python scripts/train_volume_forecast.py
python scripts/train_late_risk_model.py
python scripts/make_charts.py
python scripts/build_docx.py
```

## Key findings

- Volume forecast MAE of 14.39 shipments (~6.5% of daily mean) → usable for 7-day vehicle rostering.
- Late-risk ranking concentrates lateness: top-20% risk orders are 48.2% late vs 25.9% base rate. Simulated triage (priority dispatch + address re-verification, 40% prevention assumed) cuts the late rate 25.9% → 22.1%.
- Top lateness drivers: address risk, vehicles down for maintenance, route overload — all controllable.
- Honest negatives: the simplest classifier beat the ensembles; tuning had diminishing returns; hour prediction failed (R² ≈ 0.02).

## Full report

`Week4_Logistics_Predictive_Modeling_Report.docx` — problem definition, methodology, real evaluation metrics, model interpretation, quantified optimization strategies, limitations.

## Tech stack

Python 3 · pandas · scikit-learn · numpy · matplotlib · python-docx
