"""Render report.md -> Week4_Logistics_Predictive_Modeling_Report.docx.

Lightweight markdown renderer (headings, bold, bullets, pipe tables, fenced
code, ![caption](path) images). Charts are embedded from ../charts/.
"""
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent  # logistics_week4_report/
SRC = ROOT / "report.md"
OUT = Path.home() / "workspace" / "your_files" / "Week4_Logistics_Predictive_Modeling_Report.docx"

doc = Document()
for s in doc.sections:
    s.left_margin = Inches(1); s.right_margin = Inches(1)

style = doc.styles["Normal"]
style.font.name = "Calibri"; style.font.size = Pt(11)
for h, sz in [("Heading 1", 15), ("Heading 2", 13)]:
    st = doc.styles[h]; st.font.size = Pt(sz); st.font.color.rgb = RGBColor(0x1F, 0x3B, 0x63)

def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:fill"), hexcolor)
    tcPr.append(shd)

def add_runs(par, text):
    """Add runs handling **bold** and *italic* inline."""
    for i, tok in enumerate(re.split(r"(\*\*.+?\*\*|\*[^*]+?\*)", text)):
        if not tok:
            continue
        run = par.add_run()
        if tok.startswith("**") and tok.endswith("**"):
            run.text = tok[2:-2]; run.bold = True
        elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
            run.text = tok[1:-1]; run.italic = True
        else:
            run.text = tok

def add_image(line):
    m = re.match(r"!\[(.*?)\]\((.*?)\)", line.strip())
    if not m:
        return
    caption, rel = m.group(1), m.group(2)
    img = (ROOT / rel).resolve()
    par = doc.add_paragraph(); par.alignment = WD_ALIGN_PARAGRAPH.CENTER
    par.add_run().add_picture(str(img), width=Inches(5.8))
    cap = doc.add_paragraph(); cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = cap.add_run(caption); run.italic = True; run.font.size = Pt(9.5)
    run.font.color.rgb = RGBColor(0x44, 0x44, 0x44)

lines = SRC.read_text().splitlines()
i = 0
while i < len(lines):
    ln = lines[i]
    s = ln.strip()
    if not s or s == "---":
        i += 1; continue
    if s.startswith("```"):
        code = []
        i += 1
        while i < len(lines) and not lines[i].strip().startswith("```"):
            code.append(lines[i]); i += 1
        i += 1
        for cl in code:
            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(1); p.paragraph_format.space_before = Pt(1)
            r = p.add_run(cl if cl else " "); r.font.name = "Consolas"; r.font.size = Pt(8.5)
            r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
            pPr = p._p.get_or_add_pPr()
            shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear"); shd.set(qn("w:fill"), "F2F2F2")
            pPr.append(shd)
        continue
    if s.startswith("!["):
        add_image(s); i += 1; continue
    if s.startswith("|"):
        tbl_lines = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            tbl_lines.append(lines[i].strip()); i += 1
        rows = [[c.strip() for c in r.strip("|").split("|")] for r in tbl_lines]
        rows = [r for r in rows if not all(set(c) <= set("-: ") for c in r)]  # drop separator
        t = doc.add_table(rows=len(rows), cols=len(rows[0])); t.style = "Light Grid Accent 1"
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cell = t.cell(ri, ci); cell.text = ""
                add_runs(cell.paragraphs[0], val)
                for p in cell.paragraphs:
                    for r in p.runs: r.font.size = Pt(9.5)
                if ri == 0:
                    shade(cell, "1F3B63")
                    for p in cell.paragraphs:
                        for r in p.runs:
                            r.bold = True; r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        doc.add_paragraph().paragraph_format.space_after = Pt(2)
        continue
    if s.startswith("# "):
        doc.add_paragraph(s[2:], style="Title"); i += 1; continue
    if s.startswith("## "):
        doc.add_paragraph(s[3:], style="Heading 1"); i += 1; continue
    if s.startswith("### "):
        doc.add_paragraph(s[4:], style="Heading 2"); i += 1; continue
    if s.startswith("- "):
        p = doc.add_paragraph(style="List Bullet"); add_runs(p, s[2:]); i += 1; continue
    if re.fullmatch(r"\*[^*]+\*", s):  # standalone italic caption line
        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(s[1:-1]); r.italic = True; r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor(0x44, 0x44, 0x44); i += 1; continue
    p = doc.add_paragraph(); add_runs(p, s); i += 1

OUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(OUT)
print("saved", OUT, f"({OUT.stat().st_size/1024:.0f} KB)")
