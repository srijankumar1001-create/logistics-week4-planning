"""Generate the Week 4 synthetic logistics dataset (fixed seeds, reproducible).

Same design as the Week 3 simulation, extended to 2026-04-01 .. 2026-12-31
(275 days) and re-seeded (SEED=202604). Encodes the Week 3 measured patterns:
zone-level OTD disparities, weekend volume dip, festival/promo spikes,
monsoon penalty in semi-urban zones, long-tailed delivery times, and
distance-driven costs.

Outputs:
    data/deliveries.parquet  - one row per delivery (dispatch-time features +
                               outcome columns)
    data/daily.parquet       - one row per day (shipments, fuel price, temp)
"""
import numpy as np
import pandas as pd
from pathlib import Path

SEED = 202604
rng = np.random.default_rng(SEED)
OUT = Path(__file__).resolve().parent.parent / "data"
OUT.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- zone setup
# Shares / late-rates / failure-rates follow the Week 3 measured tables.
ZONES = {
    "Z1": dict(share=0.1813, late=0.171, fail=0.067, ztype="urban",           km=(8, 20)),
    "Z2": dict(share=0.1551, late=0.185, fail=0.079, ztype="urban",           km=(8, 20)),
    "Z3": dict(share=0.1432, late=0.192, fail=0.076, ztype="urban",           km=(9, 22)),
    "Z4": dict(share=0.1203, late=0.224, fail=0.089, ztype="urban",           km=(10, 24)),
    "Z5": dict(share=0.1016, late=0.393, fail=0.133, ztype="semi-urban",      km=(28, 60)),
    "Z6": dict(share=0.0801, late=0.324, fail=0.091, ztype="semi-urban",      km=(25, 55)),
    "Z7": dict(share=0.1199, late=0.280, fail=0.167, ztype="urban-congested", km=(8, 18)),
    "Z8": dict(share=0.0984, late=0.421, fail=0.131, ztype="semi-urban",      km=(30, 65)),
}
zone_ids = list(ZONES)
zone_p = np.array([ZONES[z]["share"] for z in zone_ids])
zone_p = zone_p / zone_p.sum()  # normalize rounding dust

FAIL_REASONS = ["customer_unavailable", "wrong_address", "gated_no_access",
                "vehicle_breakdown", "weather"]
FAIL_P = np.array([0.454, 0.261, 0.139, 0.078, 0.067])
FAIL_P = FAIL_P / FAIL_P.sum()

# ------------------------------------------------------------------ calendar
def _ndtri(p):
    """Inverse standard-normal CDF (Acklam's approximation). No scipy needed."""
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    import math
    plow, phigh = 0.02425, 1 - 0.02425
    if p < plow:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) / \
               ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1)
    if p > phigh:
        q = math.sqrt(-2 * math.log(1 - p))
        return -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) / \
                 ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1)
    q = p - 0.5
    r = q * q
    return (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5]) * q / \
           (((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4]) * r + 1)

_ppf = _ndtri
dates = pd.date_range("2026-04-01", "2026-12-31", freq="D")
n_days = len(dates)
dow = dates.dayofweek.values  # Mon=0

dow_mult = np.array([1.05, 1.00, 1.00, 1.02, 1.10, 0.85, 0.72])[dow]
drift = 1.0 + 0.0006 * np.arange(n_days)                      # gentle growth

promo = np.zeros(n_days)
def add_promo(start, end, mult):
    m = (dates >= start) & (dates <= end)
    promo[m] = np.maximum(promo[m], mult)
add_promo("2026-06-12", "2026-06-14", 1.40)   # Summer sale
add_promo("2026-07-24", "2026-07-26", 1.30)   # Monsoon clearance
add_promo("2026-08-14", "2026-08-16", 1.80)   # Independence Day sale
add_promo("2026-10-20", "2026-11-03", 1.70)   # Diwali window
add_promo("2026-12-23", "2026-12-26", 1.50)   # Christmas
promo = np.where(promo == 0, 1.0, promo)

shipments = (200 * dow_mult * drift * promo + rng.normal(0, 12, n_days)).round().astype(int)
shipments = np.maximum(shipments, 60)

fuel = 92.0 + np.cumsum(rng.normal(0, 0.25, n_days))
fuel = np.clip(fuel, 90.0, 101.0).round(2)
temp = (30 + 6 * np.sin(2 * np.pi * (np.arange(n_days) - 100) / 365)
        + rng.normal(0, 1.5, n_days)).round(1)

daily = pd.DataFrame({"date": dates, "shipments": shipments,
                      "fuel_price_rs_l": fuel, "temp_c": temp,
                      "promo_mult": promo})
daily.to_csv(OUT / "daily.csv", index=False)

# --------------------------------------------------------------- deliveries
# Pass 1: dispatch-time attributes (vehicle assignment enables a learnable
# congestion signal). Pass 2 (vectorized): delivery hours with systematic
# effects - zone base, vehicle reliability, route load, monsoon - plus noise.
rows = []
monsoon = ((dates.month >= 6) & (dates.month <= 9)).astype(int)

VEHICLES = [f"V{i:02d}" for i in range(1, 13)]
veh_factor = {v: float(f) for v, f in
              zip(VEHICLES, rng.uniform(0.85, 1.25, size=len(VEHICLES)))}

for i, d in enumerate(dates):
    n = int(shipments[i])
    z_draw = rng.choice(zone_ids, size=n, p=zone_p)
    v_draw = rng.choice(VEHICLES, size=n)
    is_monsoon = monsoon[i]
    is_promo = promo[i] > 1.0
    # hub-level disruption known at dispatch: vehicles in maintenance today
    down_today = int(rng.poisson(0.7))
    for z, v in zip(z_draw, v_draw):
        cfg = ZONES[z]
        # first-attempt failure (address risk + monsoon raise it)
        address_risk = rng.random() < {"urban": 0.18, "urban-congested": 0.22,
                                       "semi-urban": 0.30}[cfg["ztype"]]
        p_fail = cfg["fail"] * (1.35 if address_risk else 1.0) * (1.2 if is_monsoon else 1.0)
        failed = rng.random() < min(p_fail, 0.6)
        reason = rng.choice(FAIL_REASONS, p=FAIL_P) if failed else None
        pkg = round(float(rng.lognormal(0.4, 0.8)), 2)
        lo, hi = cfg["km"]
        planned = round(float(rng.uniform(lo, hi)), 1)
        actual = round(planned * (1 + rng.normal(0.133, 0.08)), 1)
        dev = round((actual - planned) / planned * 100, 1)
        cost = round(45 + 4.2 * actual + 0.9 * (fuel[i] - 92) + rng.normal(0, 6), 2)
        rows.append({
            "date": d, "zone": z, "zone_type": cfg["ztype"], "vehicle_id": v,
            "dow": int(dow[i]), "month": int(d.month),
            "monsoon": int(is_monsoon), "promo_day": int(is_promo),
            "package_kg": pkg, "planned_km": planned, "actual_km": actual,
            "route_deviation_pct": dev, "address_risk": int(address_risk),
            "customer_avail": int(rng.random() > (0.30 if address_risk else 0.12)),
            "fuel_price_rs_l": float(fuel[i]), "temp_c": float(temp[i]),
            "vehicles_down": down_today,
            "first_attempt_failed": int(failed),
            "failure_reason": reason,
            "cost_per_delivery_rs": cost,
        })

deliv = pd.DataFrame(rows)
deliv.insert(0, "delivery_id", ["D%06d" % (k + 1) for k in range(len(deliv))])

# route load: stops per vehicle-day relative to a 20-stop planning capacity
stops = deliv.groupby(["date", "vehicle_id"]).size().rename("stops")
deliv = deliv.join(stops, on=["date", "vehicle_id"])
deliv["route_load"] = (deliv["stops"] / 20.0).round(3)

# Pass 2: delivery hours = systematic effects x lognormal noise
# Systematic effects are deliberately strong: vehicle reliability, route
# overload on peak days, hub-level vehicle downtime, monsoon in semi-urban
# zones, and address rework are the learnable drivers the models must find.
SIGMA = 0.32
# base mass calibrated to ~22% of the zone target (empirically tuned so the
# extended 9-month dataset measures OTD ~= 74.5%, matching Week 3; the
# systematic operational effects supply the remaining lateness).
mu_z = {z: np.log(48) - SIGMA * _ppf(1 - max(c["late"] * 0.12 - c["fail"] * 0.5, 0.015))
        for z, c in ZONES.items()}
N = len(deliv)
mu_arr = deliv["zone"].map(mu_z).values
is_tail = rng.random(N) < 0.025
base = np.where(is_tail, rng.lognormal(4.6, 0.8, N),
                rng.lognormal(mu_arr, SIGMA))
veh_f = deliv["vehicle_id"].map(veh_factor).values
load_f = 1 + 0.40 * np.maximum(0, deliv["route_load"].values - 1.0)
down_f = 1 + 0.20 * deliv["vehicles_down"].values
monsoon_f = np.where((deliv["monsoon"] == 1) &
                     (deliv["zone_type"] == "semi-urban"), 1.32, 1.0)
addr_delay = np.where((deliv["address_risk"] == 1) & (rng.random(N) < 0.65),
                      rng.uniform(10, 26, N), 0.0)
fail_delay = np.where(deliv["first_attempt_failed"] == 1,
                      rng.uniform(24, 72, N), 0.0)
deliv["delivery_hours"] = np.round(base * veh_f * load_f * down_f * monsoon_f
                                  + addr_delay + fail_delay, 1)
deliv["late"] = (deliv["delivery_hours"] > 48).astype(int)
deliv["on_time"] = 1 - deliv["late"]
deliv.to_csv(OUT / "deliveries.csv", index=False)

# ------------------------------------------------------------------ summary
print(f"days={n_days} deliveries={len(deliv)}")
print(f"overall late rate (SLA breach) = {deliv['late'].mean():.3f}")
print(f"overall OTD                    = {deliv['on_time'].mean():.3f}")
print(f"mean daily shipments           = {daily['shipments'].mean():.1f}")
print("\nper-zone late rate / failure rate / mean cost:")
ztab = deliv.groupby("zone").agg(late=("late", "mean"), fail=("first_attempt_failed", "mean"),
                                 cost=("cost_per_delivery_rs", "mean"), n=("late", "size"))
print(ztab.round(3).to_string())
print("\nsemi-urban late:", round(deliv[deliv.zone_type == "semi-urban"]["late"].mean(), 3),
      "| urban late:", round(deliv[deliv.zone_type == "urban"]["late"].mean(), 3))
print("saved:", OUT / "deliveries.csv", "|", OUT / "daily.csv")
